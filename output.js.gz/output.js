const girlfriend = "张艺伟";
console.log("I want you be my wife!!!", girlfriend);
